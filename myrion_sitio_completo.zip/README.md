# Myrion Web

Sitio oficial de **Myrion**, que ofrece soluciones avanzadas para seguridad y anonimato.

## Contenido

- `index.html`: Página principal
- `instalocker.html`: Página de pago para Instalocker
- `spoof-1time.html`: Página de pago para Spoof (1 Time)
- `spoof-lifetime.html`: Página de pago para Spoof (Lifetime)

## Cómo publicarlo en GitHub Pages

1. Crea un nuevo repositorio en GitHub (ej: `myrion-web`).
2. Sube todos los archivos.
3. Ve a `Settings` → `Pages` y elige la rama `main` y carpeta `/root`.
4. Tu sitio estará disponible en `https://<tu-usuario>.github.io/myrion-web/`.

---

© 2025 Myrion. Todos los derechos reservados.
